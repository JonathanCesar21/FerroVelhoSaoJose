<h2>você recebeu um novo contato</h2>

<p><strong>NOME:</strong>{{$data['nome']}}</p>
<p><strong>EMAIL:</strong>{{$data['email']}}</p>
<p><strong>MENSAGEM:</strong>{{$data['mensagem']}}</p>