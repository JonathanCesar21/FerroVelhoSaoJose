<h2>você recebeu um novo contato</h2>

<p><strong>NOME:</strong><?php echo e($data['nome']); ?></p>
<p><strong>EMAIL:</strong><?php echo e($data['email']); ?></p>
<p><strong>MENSAGEM:</strong><?php echo e($data['mensagem']); ?></p><?php /**PATH C:\Users\Jonathan\Desktop\Trabalho\FerroVelhoSaoJose\resources\views/layouts/message.blade.php ENDPATH**/ ?>